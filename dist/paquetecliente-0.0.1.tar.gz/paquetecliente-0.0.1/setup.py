from setuptools import setup

setup(
    author="Giovanni",
    author_email="giovannifrancisco.98.gf@gmail.com",
    description="Paquete distribuido para segunda pre-entrega",
    version="0.0.1",
    name="PaqueteCliente",
    packages=['paqueteCliente','paqueteEntrega1']
)
